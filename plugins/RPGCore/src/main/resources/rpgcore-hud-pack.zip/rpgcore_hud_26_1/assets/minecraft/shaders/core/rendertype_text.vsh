#version 330
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 3

#moj_import <fog.glsl>
#moj_import <sample_lightmap.glsl>
#moj_import <dynamictransforms.glsl>
#moj_import <projection.glsl>
#moj_import <globals.glsl>

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
uniform sampler2D Sampler0;
uniform sampler2D Sampler2;
uniform vec3 ChunkOffset;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec2 ui = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));
    vertexColor = Color;

    if (pos.y >= ui.y && ProjMat[3].x == -1) {
        int bit = int(pos.y) >> HEIGHT_BIT;
        if (((bit >> MAX_BIT) & 1) == 1) {
            int id = bit - (1 << MAX_BIT);
            pos.x -= 0.5 * ui.x;
            pos.y -= (bit << HEIGHT_BIT) + ADD_OFFSET + DEFAULT_OFFSET;
            float xGui = ui.x * 0.5;
            float yGui = ui.y;
            float layer = 0;

            switch (id) {
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    layer = 1;
                    break;
                case 4:
                    layer = 2;
                    break;
                case 5:
                    layer = 3;
                    break;
            }
            pos.x += xGui;
            pos.y += yGui;
            pos.z += layer;
        }
    }

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    vertexColor *= sample_lightmap(Sampler2, UV2);
#endif
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    texCoord0 = UV0;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
